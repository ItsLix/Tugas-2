import 'package:flutter/material.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'First App',
      home: Scaffold(
        appBar: AppBar(
          title: Text('Produk Toko kami'),
        ),
        body: Column(children: <Widget>[
          Image.network('https://i2.wp.com/gdm.id/wp-content/uploads/2021/01/Halfmoon-2-1024x600.jpg'),
          Text('Cupang Halfmoon', style: TextStyle(fontSize: 30, fontFamily: "Serif", height: 2.0)),
          Text('Stock : 300')
        ]),
      ),
    );
  }
}
